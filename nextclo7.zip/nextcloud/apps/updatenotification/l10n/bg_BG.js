OC.L10N.register(
    "updatenotification",
    {
    "Updated channel" : "Обновяването е отказано",
    "Updater" : "Обновяване",
    "A new version is available: %s" : "Има Нова Версия: %s",
    "Open updater" : "Отвори обновяването",
    "Your version is up to date." : "Вие разполагате с последна версия",
    "Update channel:" : "Обновяване отказано:",
    "You can always update to a newer version / experimental channel. But you can never downgrade to a more stable channel." : "Винаги може да оновите до по-нова версия / експирементален канал. Но неможете вече да върнете до по-стабилен канал.."
},
"nplurals=2; plural=(n != 1);");
