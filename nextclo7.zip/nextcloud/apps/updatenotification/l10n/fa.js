OC.L10N.register(
    "updatenotification",
    {
    "{version} is available. Get more information on how to update." : "{version} آماده است. برای چگونگی بروزرسانی اطلاعات بیشتر را دریافت نمایید.",
    "Updater" : "به روز رساننده"
},
"nplurals=1; plural=0;");
