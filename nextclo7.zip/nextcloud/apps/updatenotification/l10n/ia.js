OC.L10N.register(
    "updatenotification",
    {
    "{version} is available. Get more information on how to update." : "{version} es disponibile. Obtene plus informationes super como actualisar.",
    "Open updater" : "Aperir actualisator",
    "Your version is up to date." : "Tu version es actualisate.",
    "Update channel:" : "Canal de actualisation:",
    "You can always update to a newer version / experimental channel. But you can never downgrade to a more stable channel." : "Tu sempre pote actualisar a un version plus nove o a un canal experimental. Ma tu non potera jammais retrogradar a un canal plus stabile.",
    "Notify members of the following groups about available updates:" : "Notifica membros del gruppos sequente super actualisationes disponibile:",
    "Only notification for app updates are available." : "Notification es disponibile solmente pro actualisationes de applicationes.",
    "The selected update channel does not support updates of the server." : "Le canal de actualisation seligite non supporta actualisationes del servitor.",
    "Could not start updater, please try the manual update" : "Impossibile initiar le actualisator, per favor tenta le actualisation manual",
    "Update notifications" : "Actualisar notificationes",
    "Channel updated" : "Canal actualisate",
    "Update to %1$s is available." : "Un actualisation a %1$s es disponibile.",
    "Update for %1$s to version %2$s is available." : "Un actualisation de %1$s al version %2$s es disponibile.",
    "Update for {app} to version %s is available." : "Un actualisation del {app} al version %s es disponibile.",
    "A new version is available: %s" : "Un nove version es disponibile: %s",
    "Download now" : "Discargar ora",
    "Checked on %s" : "Verificate in %s",
    "The selected update channel makes dedicated notifications for the server obsolete." : "Le canal de actualisation selectionate face le notificationes dedicate al servitor esser obsolete."
},
"nplurals=2; plural=(n != 1);");
