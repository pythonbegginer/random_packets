OC.L10N.register(
    "updatenotification",
    {
    "Update notifications" : "Notifikatiounen aktualiséieren",
    "{version} is available. Get more information on how to update." : "{Versioun} ass verfügbar. Kréi méi Informatiounen doriwwer wéi d'Aktualiséierung ofleeft.",
    "Updated channel" : "Aktualiséierte Kanal",
    "ownCloud core" : "ownCloud Kär",
    "Update for %1$s to version %2$s is available." : "D'Aktualiséierung fir %1$s op d'Versioun %2$s ass verfügbar.",
    "A new version is available: %s" : "Eng nei Versioun ass verfügbar: %s",
    "Open updater" : "Den Aktualiséierungsprogramm opmaachen",
    "Your version is up to date." : "Déng Versioun ass aktualiséiert.",
    "Checked on %s" : "Gepréift um %s",
    "Update channel:" : "Kanal updaten:"
},
"nplurals=2; plural=(n != 1);");
