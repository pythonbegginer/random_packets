OC.L10N.register(
    "updatenotification",
    {
    "Updater" : "পরিবর্ধনকারী"
},
"nplurals=2; plural=(n != 1);");
