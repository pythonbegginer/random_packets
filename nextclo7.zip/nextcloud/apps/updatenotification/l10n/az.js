OC.L10N.register(
    "updatenotification",
    {
    "Updater" : "Yeniləyici",
    "A new version is available: %s" : "Yeni versiya mövcuddur: %s"
},
"nplurals=2; plural=(n != 1);");
