OC.L10N.register(
    "updatenotification",
    {
    "{version} is available. Get more information on how to update." : "La version {version} es disponibla. Obtenètz mai d'informacions a prepaus d'aquesta mesa a jorn.",
    "Updated channel" : "Canal mes a jorn",
    "Update channel:" : "Canal de mesa a jorn :",
    "You can always update to a newer version / experimental channel. But you can never downgrade to a more stable channel." : "Podètz a tot moment metre a jorn cap a una version mai recenta o un canal experimental. Pasmens, poiretz pas jamai tornar a un canal mai estable."
},
"nplurals=2; plural=(n > 1);");
