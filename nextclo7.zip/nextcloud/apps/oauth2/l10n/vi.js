OC.L10N.register(
    "oauth2",
    {
    "OAuth 2.0" : "OAuth 2.0",
    "OAuth 2.0 clients" : "kết nối OAuth 2.0",
    "Add client" : "Thêm kết nối",
    "Name" : "Tên",
    "Redirection URI" : "Liên kết chuyển tiếp",
    "Add" : "Thêm",
    "Secret" : "Mật khẩu",
    "Delete" : "Xóa"
},
"nplurals=1; plural=0;");
