OC.L10N.register(
    "oauth2",
    {
    "OAuth 2.0" : "OAuth 2.0",
    "OAuth 2.0 clients" : "OAuth 2.0 კლიენტები",
    "Add client" : "კლიენტის დამატება",
    "Name" : "სახელი",
    "Redirection URI" : "გადამისამართების URI",
    "Add" : "დამატება",
    "Client Identifier" : "კლიენტის იდენტიფიკატორი",
    "Secret" : "საიდუმლო",
    "Delete" : "წაშლა"
},
"nplurals=2; plural=(n!=1);");
