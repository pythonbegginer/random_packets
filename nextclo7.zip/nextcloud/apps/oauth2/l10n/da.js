OC.L10N.register(
    "oauth2",
    {
    "OAuth 2.0" : "OAuth 2.0",
    "OAuth 2.0 clients" : "OAuth 2.0 klienter",
    "Add client" : "Tilføj klient",
    "Name" : "Navn",
    "Redirection URI" : "Viderestilling URI",
    "Add" : "Tilføj",
    "Client Identifier" : "Klient ID",
    "Secret" : "Hemmelighed",
    "Delete" : "Slet"
},
"nplurals=2; plural=(n != 1);");
