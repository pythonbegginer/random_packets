OC.L10N.register(
    "oauth2",
    {
    "OAuth 2.0 clients" : "OAuth 2.0 kliendid",
    "Add client" : "Lisa klient",
    "Name" : "Nimi",
    "Redirection URI" : "Suunamise URI",
    "Add" : "Lisa",
    "Client Identifier" : "Kliendi identifikaator",
    "Secret" : "Saladus",
    "Delete" : "Kustuta"
},
"nplurals=2; plural=(n != 1);");
