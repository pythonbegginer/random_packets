<?php
	declare(strict_types=1);
	\OCP\Util::addScript('dashboard', 'dashboard');
?>
<div id="app-content-vue"></div>
