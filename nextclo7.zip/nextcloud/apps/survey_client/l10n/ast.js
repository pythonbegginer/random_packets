OC.L10N.register(
    "survey_client",
    {
    "An error occurred while sending your report." : "Asocedió un fallu entrín s'unviaba'l to informe.",
    "Usage survey" : "Encuesta d'usu",
    "Do you want to help us to improve Nextcloud by providing some anonymized data about your setup and usage? You can disable it at any time in the admin settings again." : "¿Quies ayudanos a ameyorar Nextcloud apurriendo dellos datos anínimos tocante a la to configuración y usu? Pues desactivalo en cualesquier momentu nos axustes d'almin.",
    "Not now" : "Agora non",
    "Send usage" : "Unviar usu",
    "Never" : "Enxamás",
    "Data to send" : "Datos pa unviar"
},
"nplurals=2; plural=(n != 1);");
