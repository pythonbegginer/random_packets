OC.L10N.register(
    "survey_client",
    {
    "An error occurred while sending your report." : " тайланг илгээх явцад алдаа гарлаа",
    "Database environment <em>(type, version, database size)</em>" : "Өгөгдлийн сангийн орчин  (төрөл, хувилбар, мэдээллийн сангийн хэмжээ) ",
    "Usage survey" : "хэрэглээ судалгаа",
    "Not now" : "одоо биш",
    "Never" : "хэзээч",
    "Data to send" : "өгөгдлийг илгээх",
    "Last report" : "сүүлийн тайлан"
},
"nplurals=2; plural=(n != 1);");
