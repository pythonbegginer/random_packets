OC.L10N.register(
    "firstrunwizard",
    {
    "Copied!" : "Eilet eo !",
    "Not supported!" : "Diembreget eo ! ",
    "Press ⌘-C to copy." : "Pouezañ war ⌘-C evit eilañ. ",
    "Press Ctrl-C to copy." : "Pouezañ war Ctrl-C evit eilañ. ",
    "Schedule work & meetings, synced with all your devices." : "Implij amzer & emvodoù, kemprenet gant toud o ardivinkoù.",
    "Keep your colleagues and friends in one place without leaking their private info." : "Kavit o mignoned ha genseurted en ul lec'h, hep reiñ o ditouroù prevez.",
    "Simple email app nicely integrated with Files, Contacts and Calendar." : "Ur meziant email simpl enfammet gant Restroù, Darempredoù ha Deizataer.",
    "About" : "Diwar-benn",
    "Desktop client" : "Kliant burev",
    "Android app" : "Meziant Android",
    "iOS app" : "Meziant iOS",
    "Server address" : "Chom-lec'h ar servijour",
    "Copy link" : "Kopiañ al liamm"
},
"nplurals=5; plural=((n%10 == 1) && (n%100 != 11) && (n%100 !=71) && (n%100 !=91) ? 0 :(n%10 == 2) && (n%100 != 12) && (n%100 !=72) && (n%100 !=92) ? 1 :(n%10 ==3 || n%10==4 || n%10==9) && (n%100 < 10 || n% 100 > 19) && (n%100 < 70 || n%100 > 79) && (n%100 < 90 || n%100 > 99) ? 2 :(n != 0 && n % 1000000 == 0) ? 3 : 4);");
