OC.L10N.register(
    "firstrunwizard",
    {
    "Copied!" : "Kopiert!",
    "Not supported!" : "Ikkje støtta!",
    "Press ⌘-C to copy." : "Trykk  ⌘-C for å kopiere.",
    "Press Ctrl-C to copy." : "Trykk Ctrl-C for å kopiere.",
    "About" : "Om",
    "Get the apps to sync your files" : "Få app-ar som kan synkronisera filene dine",
    "Access files via WebDAV" : "Bruk filene dine over WebDAV",
    "A safe home for all your data" : "Eit trygt heim for all din data",
    "Server address" : "Server adresse"
},
"nplurals=2; plural=(n != 1);");
