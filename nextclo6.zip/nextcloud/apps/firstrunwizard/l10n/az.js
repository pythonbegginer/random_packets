OC.L10N.register(
    "firstrunwizard",
    {
    "About" : "Haqqında",
    "Get the apps to sync your files" : "Fayllarınızın sinxronizasiyası üçün proqramları götürün",
    "Desktop client" : "Desktop client",
    "Android app" : "Android proqramı",
    "iOS app" : "iOS proqramı",
    "Connect your desktop apps to %s" : "Desktop proqramınızı %s-ə qoşun",
    "Access files via WebDAV" : "Fayllara WebDAV ilə yetki",
    "Server address" : "Server ünvanı",
    "Copy link" : "linki nüsxələ"
},
"nplurals=2; plural=(n != 1);");
