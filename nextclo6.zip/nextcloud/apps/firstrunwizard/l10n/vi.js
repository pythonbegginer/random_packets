OC.L10N.register(
    "firstrunwizard",
    {
    "Copied!" : "Đã sao chép!",
    "Not supported!" : "Không hỗ trợ!",
    "Press ⌘-C to copy." : "Bấm ⌘-C để sao chép.",
    "Press Ctrl-C to copy." : "Bấm Ctrl-C để sao chép.",
    "About" : "Thông tin",
    "Get the apps to sync your files" : "Nhận ứng dụng để đồng bộ file của bạn",
    "Android app" : "Ứng dụng Android",
    "iOS app" : "Ứng dụng IOS",
    "Access files via WebDAV" : "Truy cập file qua WebDAV",
    "Server address" : "Địa chỉ máy chủ",
    "Copy link" : "Sao chép liên kết"
},
"nplurals=1; plural=0;");
