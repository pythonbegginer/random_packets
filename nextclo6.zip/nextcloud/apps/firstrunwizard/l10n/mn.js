OC.L10N.register(
    "firstrunwizard",
    {
    "Copied!" : "Хуулсан!",
    "Not supported!" : "Дэмжигдэхгүй",
    "Press ⌘-C to copy." : "Хуулахын тулд ⌘-C дарна уу.",
    "Press Ctrl-C to copy." : "Хуулахын тулд Ctrl-C дарна уу.",
    "About" : "Тухай",
    "Desktop client" : "захиалагчийн дэлгэц",
    "Server address" : "хүлээн авагчийн хаяг"
},
"nplurals=2; plural=(n != 1);");
