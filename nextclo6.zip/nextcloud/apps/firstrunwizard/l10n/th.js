OC.L10N.register(
    "firstrunwizard",
    {
    "Copied!" : "คัดลอกแล้ว",
    "Not supported!" : "ไม่สนับสนุน",
    "Press ⌘-C to copy." : "กด ⌘-C เพื่อคัดลอก",
    "Press Ctrl-C to copy." : "กด Ctrl-C เพื่อคัดลอก",
    "About" : "เกี่ยวกับเรา",
    "Get the apps to sync your files" : "ใช้แอพพลิเคชันเพื่อประสานไฟล์ข้อมูลของคุณ",
    "Desktop client" : "เดสก์ทอปผู้ใช้",
    "Android app" : "แอพฯ แอนดรอยด์",
    "iOS app" : "แอพฯ IOS",
    "Connect your desktop apps to %s" : "เชื่อมต่อแอพพลิเคชันเดสก์ทอปของคุณไปยัง %s",
    "Access files via WebDAV" : "เข้าถึงไฟล์ผ่าน WebDAV",
    "Server address" : "ที่อยู่เซิร์ฟเวอร์",
    "Copy link" : "คัดลอกลิงค์"
},
"nplurals=1; plural=0;");
