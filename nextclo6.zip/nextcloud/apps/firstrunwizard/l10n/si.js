OC.L10N.register(
    "firstrunwizard",
    {
    "Not supported!" : "සහාය නොදක්වයි!",
    "Press ⌘-C to copy." : "පිටපත් කිරීමට ⌘-C ඔබන්න.",
    "Press Ctrl-C to copy." : "පිටපත් කිරීමට Ctrl-C ඔබන්න.",
    "App recommendation: Social" : "යෙදුම් නිර්දේශය: සමාජ",
    "About" : "පිළිබඳව",
    "Server address" : "සේවාදායක ලිපිනය",
    "Copy link" : "සබැඳිය පිටපත් කරන්න",
    "Browse the app store" : "යෙදුම් ගබඩාව පිරික්සන්න"
},
"nplurals=2; plural=(n != 1);");
