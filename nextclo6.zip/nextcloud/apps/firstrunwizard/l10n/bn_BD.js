OC.L10N.register(
    "firstrunwizard",
    {
    "About" : "সমপরকে",
    "Get the apps to sync your files" : "আপনার ফাইলসমূহ সিংক করতে অ্যাপস নিন",
    "Connect your desktop apps to %s" : "আপনার ডেস্কটপ অ্যাপসমূহ %s এর সংগে যুক্ত করুন",
    "Access files via WebDAV" : "WebDAV হয়ে ফাইলে প্রবেশ করুন",
    "Server address" : "সার্ভার ঠিকানা",
    "Copy link" : "লিঙ্ক কপি করো"
},
"nplurals=2; plural=(n != 1);");
