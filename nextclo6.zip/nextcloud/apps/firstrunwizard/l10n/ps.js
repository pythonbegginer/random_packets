OC.L10N.register(
    "firstrunwizard",
    {
    "Copied!" : "کاپي شو!",
    "Not supported!" : "د کار نه کېږي",
    "Press ⌘-C to copy." : "د کاپي لپاره د ⌘-C تڼۍ کېکاږئ.",
    "Press Ctrl-C to copy." : "د کاپي لپاره د Ctrl-C تڼۍ کېکاږئ.",
    "Copy link" : "لېنک کاپي کول"
},
"nplurals=2; plural=(n != 1);");
