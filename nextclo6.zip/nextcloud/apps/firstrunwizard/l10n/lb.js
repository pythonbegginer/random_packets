OC.L10N.register(
    "firstrunwizard",
    {
    "Copied!" : "Kopéiert!",
    "Not supported!" : "Nët ennerstëtzt!",
    "Press ⌘-C to copy." : "Dréck ⌘-C fir ze kopéieren.",
    "Press Ctrl-C to copy." : "Dréck CTRL-C fir ze kopéieren.",
    "About" : "Iwwer",
    "Get the apps to sync your files" : "D'Apps op Fichieren syncen",
    "Desktop client" : "Desktop-Programm",
    "Android app" : "Android-App",
    "iOS app" : "iOS-App",
    "Server address" : "Server-Adress",
    "Copy link" : "Link kopéieren"
},
"nplurals=2; plural=(n != 1);");
