OC.L10N.register(
    "firstrunwizard",
    {
    "Copied!" : "Kopirano",
    "Get the apps to sync your files" : "Koristite aplikacije za sinhronizaciju svojih datoteka",
    "Desktop client" : "Desktop klijent",
    "Android app" : "Android aplikacija",
    "iOS app" : "iOS aplikacija",
    "Server address" : "Adresa servera"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);");
