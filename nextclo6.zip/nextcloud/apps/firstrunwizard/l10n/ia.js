OC.L10N.register(
    "firstrunwizard",
    {
    "Copied!" : "Copiate!",
    "Not supported!" : "Non supportate!",
    "Press ⌘-C to copy." : "Pulsa ⌘-C pro copiar.",
    "Press Ctrl-C to copy." : "Pulsa Ctrl-C pro copiar.",
    "First run wizard" : "Assistente del prime execution",
    "Add your profile information! Set a profile picture and full name for easier recognition across all features." : "Adde tu information de profilo! Assigna un pictura de profilo e tu nomine complete pro haber un recognition plus facile trans tote functionalitates.",
    "Add your profile information! Set a full name for easier recognition across all features." : "Adde tu information de profilo! Assigna tu nomine complete pro un recognition plus facile trans tote functionalitates.",
    "Add your profile information! Set a profile picture for easier recognition across all features." : "Adde tu information de profilo! Assigna un pictura de profilo pro un recognition plus facile trans tote functionalitates.",
    "About" : "A proposito",
    "Get the apps to sync your files" : "Obtene le applicationes pro synchronisar tu files",
    "Desktop client" : "Cliente de Scriptorio",
    "Android app" : "Application Android",
    "iOS app" : "Application iOS",
    "Connect your desktop apps to %s" : "Connecte tu application de scriptorio a %s",
    "Access files via WebDAV" : "Accede a files via WebDAV",
    "Server address" : "Adresse de servitor",
    "Copy link" : "Copiar ligamine"
},
"nplurals=2; plural=(n != 1);");
