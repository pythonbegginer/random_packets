OC.L10N.register(
    "firstrunwizard",
    {
    "Copied!" : "Копирано!",
    "Not supported!" : "Није подржано!",
    "Press ⌘-C to copy." : "Притисни ⌘-C за копирање.",
    "Press Ctrl-C to copy." : "Притисни Ctrl-C за копирање.",
    "About" : "O programu",
    "Server address" : "Adresa servera",
    "Copy link" : "Kopiraj vezu"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);");
