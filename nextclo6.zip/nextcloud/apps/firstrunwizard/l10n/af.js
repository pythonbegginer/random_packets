OC.L10N.register(
    "firstrunwizard",
    {
    "Copied!" : "Gekopieer!",
    "Not supported!" : "Word nie ondersteun nie!",
    "Press ⌘-C to copy." : "Druk ⌘-C om te kopieer.",
    "Press Ctrl-C to copy." : "Druk Ctrl-C om te kopieer.",
    "About" : "Aangaande",
    "Desktop client" : "Werkskermkliënt",
    "Android app" : "Android-toep",
    "iOS app" : "iOS-toep",
    "A safe home for all your data" : "’n Veilige tuiste vir al u data",
    "Server address" : "Bedieneradres",
    "Copy link" : "Kopieer skakel"
},
"nplurals=2; plural=(n != 1);");
