OC.L10N.register(
    "firstrunwizard",
    {
    "Copied!" : "Disalin!",
    "Not supported!" : "Tidak menyokong!",
    "Press ⌘-C to copy." : "Tekan ⌘-C untuk menyalin.",
    "Press Ctrl-C to copy." : "Tekan Ctrl-C untuk menyalin.",
    "About" : "Mengenai",
    "Server address" : "Alamat pelayan"
},
"nplurals=1; plural=0;");
