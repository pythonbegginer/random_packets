OC.L10N.register(
    "files",
    {
    "Download" : "Njipuk"
},
"nplurals=2; plural=(n != 1);");
