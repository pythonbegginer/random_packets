OC.L10N.register(
    "files",
    {
    "_%n folder_::_%n folders_" : ["","","",""],
    "_%n file_::_%n files_" : ["","","",""],
    "_Uploading %n file_::_Uploading %n files_" : ["","","",""],
    "_matches '{filter}'_::_match '{filter}'_" : ["","","",""]
},
"nplurals=4; plural=(n==1 ? 0 : n==0 || ( n%100>1 && n%100<11) ? 1 : (n%100>10 && n%100<20 ) ? 2 : 3);");
