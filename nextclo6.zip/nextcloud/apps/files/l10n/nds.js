OC.L10N.register(
    "files",
    {
    "Files" : "Dateien",
    "Close" : "Schließen",
    "Download" : "Download",
    "Delete" : "Löschen",
    "Details" : "Details",
    "Could not move \"{file}\", target exists" : "\"{file}\" konnte nicht verschoben werden, weil das Ziel schon existiert",
    "Could not move \"{file}\"" : "\"{file}\" konnte nicht verschoben werden",
    "Name" : "Name",
    "New" : "Neu",
    "New folder" : "Neuer Ordner",
    "Upload" : "Hochladen",
    "Settings" : "Einstellungen",
    "WebDAV" : "WebDAV"
},
"nplurals=2; plural=(n != 1);");
