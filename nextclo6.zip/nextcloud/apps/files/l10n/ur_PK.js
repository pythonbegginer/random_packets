OC.L10N.register(
    "files",
    {
    "Unknown error" : "غیر معروف خرابی",
    "Close" : "بند ",
    "Download" : "ڈاؤن لوڈ،",
    "Delete" : "حذف کریں",
    "Unshare" : "شئیرنگ ختم کریں",
    "Name" : "اسم",
    "Save" : "حفظ",
    "Settings" : "ترتیبات"
},
"nplurals=2; plural=(n != 1);");
