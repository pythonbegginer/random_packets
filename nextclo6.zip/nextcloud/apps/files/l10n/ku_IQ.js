OC.L10N.register(
    "files",
    {
    "Files" : "په‌ڕگەکان",
    "Close" : "دابخه",
    "Favorites" : "دڵخوازەکان",
    "Download" : "داگرتن",
    "Select" : "دیاریکردنی",
    "Name" : "ناو",
    "Folder" : "بوخچه",
    "Upload" : "بارکردن",
    "Save" : "پاشکه‌وتکردن",
    "Settings" : "ڕێکخستنه‌کان"
},
"nplurals=2; plural=(n != 1);");
