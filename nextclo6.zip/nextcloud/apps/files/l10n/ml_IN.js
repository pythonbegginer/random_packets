OC.L10N.register(
    "files",
    {
    "Files" : "ഫയലുകൾ",
    "You created %1$s" : "നിങ്ങൾ %1$s സൃഷ്ടിച്ചു",
    "%2$s created %1$s" : "%2$s %1$s സൃഷ്ടിച്ചു",
    "You changed %1$s" : "നിങ്ങൾ %1$s പരിഷ്കരിച്ചു",
    "%2$s changed %1$s" : "%2$s %1$s പരിഷ്കരിച്ചു",
    "You deleted %1$s" : "നിങ്ങൾ %1$s മായ്ച്ചു",
    "%2$s deleted %1$s" : "%2$s %1$s മായ്ച്ചു"
},
"nplurals=2; plural=(n != 1);");
