OC.L10N.register(
    "viewer",
    {
    "Viewer" : "Vidigilo",
    "Simple file viewer with slideshow for media" : "Simpla dosiervidigilo kun lumbilda prezento por aŭdvidaĵoj",
    "Show your latest holiday photos and videos like in the movies, show a glimpse of your latest novel directly from your nextcloud, choose the best GIF of your collection thanks to the direct preview of your favorites files and many more!" : "Montru viajn lastajn feriajn fotojn kaj videaĵojn  kiel en la filmoj; montru ekstrakton el via lasta romano rekte ek via Nextcloud; elektu la pli bonan GIF el via kolekto danke al la rekta antaŭrigardo de viaj preferataj dosieroj, kaj pli.",
    "Error loading {name}" : "Eraro dum ŝargo de {name}",
    "Your browser does not support videos." : "Via retumilo ne subtenas la vidaĵojn",
    "Open sidebar" : "Malfermi flankopanelon",
    "Delete" : "Forigi",
    "View" : "Vidi"
},
"nplurals=2; plural=(n != 1);");
