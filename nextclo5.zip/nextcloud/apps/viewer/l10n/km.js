OC.L10N.register(
    "viewer",
    {
    "Delete" : "លុប"
},
"nplurals=1; plural=0;");
