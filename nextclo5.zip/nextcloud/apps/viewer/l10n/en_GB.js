OC.L10N.register(
    "viewer",
    {
    "Open sidebar" : "Open sidebar",
    "Delete" : "Delete"
},
"nplurals=2; plural=(n != 1);");
