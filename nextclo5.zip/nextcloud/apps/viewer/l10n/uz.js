OC.L10N.register(
    "viewer",
    {
    "Delete" : "O'chir"
},
"nplurals=1; plural=0;");
