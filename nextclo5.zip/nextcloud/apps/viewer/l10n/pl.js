OC.L10N.register(
    "viewer",
    {
    "Viewer" : "Przeglądarka",
    "Simple file viewer with slideshow for media" : "Prosta przeglądarka plików z pokazem slajdów dla mediów",
    "Show your latest holiday photos and videos like in the movies, show a glimpse of your latest novel directly from your nextcloud, choose the best GIF of your collection thanks to the direct preview of your favorites files and many more!" : "Pokaż najnowsze zdjęcia i filmy z wakacji. Pokaż swoją najnowszą przygodę bezpośrednio z Nextcloud. Wybierz najlepszy GIF ze swojej kolekcji. I to wszystko dzięki bezpośredniemu podglądowi ulubionych plików i wielu innych!",
    "Your browser does not support audio." : "Twoja przeglądarka nie obsługuje dźwięku.",
    "Error loading {name}" : "Błąd podczas ładowania {name}",
    "Your browser does not support videos." : "Twoja przeglądarka nie obsługuje wideo.",
    "Open sidebar" : "Otwórz pasek boczny",
    "Download" : "Pobierz",
    "Delete" : "Usuń",
    "There is no plugin available to display this file type" : "Brak dostępnej wtyczki do wyświetlania tego typu plików",
    "View" : "Podgląd"
},
"nplurals=4; plural=(n==1 ? 0 : (n%10>=2 && n%10<=4) && (n%100<12 || n%100>14) ? 1 : n!=1 && (n%10>=0 && n%10<=1) || (n%10>=5 && n%10<=9) || (n%100>=12 && n%100<=14) ? 2 : 3);");
