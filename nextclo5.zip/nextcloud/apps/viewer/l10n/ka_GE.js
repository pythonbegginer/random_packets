OC.L10N.register(
    "viewer",
    {
    "Delete" : "წაშლა"
},
"nplurals=2; plural=(n!=1);");
