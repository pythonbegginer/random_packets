OC.L10N.register(
    "viewer",
    {
    "Delete" : "ลบ"
},
"nplurals=1; plural=0;");
