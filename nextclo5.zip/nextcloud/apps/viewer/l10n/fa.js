OC.L10N.register(
    "viewer",
    {
    "Open sidebar" : "باز کردن نوار کناری",
    "Delete" : "حذف"
},
"nplurals=2; plural=(n > 1);");
