OC.L10N.register(
    "viewer",
    {
    "Viewer" : "Visor",
    "Delete" : "Desaniciar"
},
"nplurals=2; plural=(n != 1);");
