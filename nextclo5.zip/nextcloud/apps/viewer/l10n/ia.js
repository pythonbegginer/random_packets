OC.L10N.register(
    "viewer",
    {
    "Delete" : "Deler",
    "View" : "Vider"
},
"nplurals=2; plural=(n != 1);");
