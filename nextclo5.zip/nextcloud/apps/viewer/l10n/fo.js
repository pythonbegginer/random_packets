OC.L10N.register(
    "viewer",
    {
    "Delete" : "Strika"
},
"nplurals=2; plural=(n != 1);");
