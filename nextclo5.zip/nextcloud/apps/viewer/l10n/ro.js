OC.L10N.register(
    "viewer",
    {
    "Viewer" : "Vizualizator",
    "Simple file viewer with slideshow for media" : "Vizualizator simplu de fișiere cu derulator media",
    "Show your latest holiday photos and videos like in the movies, show a glimpse of your latest novel directly from your nextcloud, choose the best GIF of your collection thanks to the direct preview of your favorites files and many more!" : "Afișează cele mai recente fotografii și videoclipuri din vacanță ca în filme, arată un fragment al ultimului tău roman direct din cloud, alege cel mai bun GIF al colecției tale datorită previzualizării directe a fișierelor tale favorite și multe altele!",
    "Error loading {name}" : "Eroare la încărcare {name}",
    "Open sidebar" : "Deschide bara laterală",
    "Delete" : "Șterge",
    "View" : "Vizualizare"
},
"nplurals=3; plural=(n==1?0:(((n%100>19)||((n%100==0)&&(n!=0)))?2:1));");
