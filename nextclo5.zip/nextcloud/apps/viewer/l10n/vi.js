OC.L10N.register(
    "viewer",
    {
    "Your browser does not support audio." : "Trình duyệt của bạn không hỗ trợ âm thanh.",
    "Error loading {name}" : "Lỗi khi tải {name}",
    "Your browser does not support videos." : "Trình duyệt của bạn không hỗ trợ video.",
    "Open sidebar" : "Mở thanh bên",
    "Delete" : "Xóa",
    "View" : "Xem"
},
"nplurals=1; plural=0;");
