OC.L10N.register(
    "viewer",
    {
    "Delete" : "ລຶບ"
},
"nplurals=1; plural=0;");
