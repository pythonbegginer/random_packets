OC.L10N.register(
    "viewer",
    {
    "Delete" : "հեռացնել"
},
"nplurals=2; plural=(n != 1);");
