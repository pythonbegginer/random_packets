OC.L10N.register(
    "viewer",
    {
    "Delete" : "Padam"
},
"nplurals=1; plural=0;");
