OC.L10N.register(
    "viewer",
    {
    "Open sidebar" : "Abrir barra lateral",
    "Delete" : "Borrar",
    "View" : "Ver"
},
"nplurals=2; plural=(n != 1);");
