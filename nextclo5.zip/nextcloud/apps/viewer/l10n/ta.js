OC.L10N.register(
    "viewer",
    {
    "Delete" : "நீக்குக"
},
"nplurals=2; plural=(n != 1);");
