OC.L10N.register(
    "viewer",
    {
    "Delete" : "Ta bort"
},
"nplurals=2; plural=(n != 1);");
