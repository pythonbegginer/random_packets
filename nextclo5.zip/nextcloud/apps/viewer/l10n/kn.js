OC.L10N.register(
    "viewer",
    {
    "Delete" : "﻿ಅಳಿಸಿ"
},
"nplurals=2; plural=(n > 1);");
