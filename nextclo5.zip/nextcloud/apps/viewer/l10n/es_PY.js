OC.L10N.register(
    "viewer",
    {
    "Viewer" : "Visor",
    "Error loading {name}" : "Se presentó un error al cargar {name}",
    "Your browser does not support videos." : "Tu navegador no soporta videos.",
    "Open sidebar" : "Abrir barra lateral",
    "Delete" : "Borrar"
},
"nplurals=2; plural=(n != 1);");
