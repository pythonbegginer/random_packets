OC.L10N.register(
    "viewer",
    {
    "Open sidebar" : "Abrir barra lateral",
    "Delete" : "Eliminar"
},
"nplurals=2; plural=(n != 1);");
