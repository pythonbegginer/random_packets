OC.L10N.register(
    "viewer",
    {
    "Viewer" : "شسیب",
    "Delete" : "ړنګول"
},
"nplurals=2; plural=(n != 1);");
