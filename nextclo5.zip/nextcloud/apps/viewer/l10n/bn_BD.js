OC.L10N.register(
    "viewer",
    {
    "Delete" : "মুছে"
},
"nplurals=2; plural=(n != 1);");
