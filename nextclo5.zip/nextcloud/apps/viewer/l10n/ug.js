OC.L10N.register(
    "viewer",
    {
    "Delete" : "ئۆچۈر"
},
"nplurals=2; plural=(n != 1);");
