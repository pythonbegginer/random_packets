OC.L10N.register(
    "viewer",
    {
    "Open sidebar" : "Ava külgriba",
    "Delete" : "Kustuta"
},
"nplurals=2; plural=(n != 1);");
