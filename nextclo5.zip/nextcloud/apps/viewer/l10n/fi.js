OC.L10N.register(
    "viewer",
    {
    "Viewer" : "Katselin",
    "Simple file viewer with slideshow for media" : "Yksinkertainen tiedostokatselin mahdollisuudella katsoa kuvia diaesityksenä",
    "Your browser does not support audio." : "Selaimesi ei tue äänentoistoa.",
    "Error loading {name}" : "Virhe ladatessa {name}",
    "Your browser does not support videos." : "Selaimesi ei tue videoita.",
    "Open sidebar" : "Avaa sivupalkki",
    "Download" : "Lataa",
    "Delete" : "Poista",
    "There is no plugin available to display this file type" : "Tämän tiedostotyypin näyttämiseksi ei ole saatavilla liitännäistä",
    "View" : "Näytä"
},
"nplurals=2; plural=(n != 1);");
