OC.L10N.register(
    "viewer",
    {
    "Error loading {name}" : "{name} පූරණය කිරීමේ දෝෂයකි"
},
"nplurals=2; plural=(n != 1);");
