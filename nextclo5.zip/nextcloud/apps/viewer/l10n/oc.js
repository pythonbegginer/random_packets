OC.L10N.register(
    "viewer",
    {
    "Viewer" : "Visualizaira",
    "Download" : "Telecargar",
    "Delete" : "Suprimir",
    "View" : "Vista"
},
"nplurals=2; plural=(n > 1);");
