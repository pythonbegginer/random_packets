OC.L10N.register(
    "viewer",
    {
    "Open sidebar" : "Отвори страничното меню",
    "Delete" : "Изтриване",
    "View" : "Изглед"
},
"nplurals=2; plural=(n != 1);");
