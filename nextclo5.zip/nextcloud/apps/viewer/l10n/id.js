OC.L10N.register(
    "viewer",
    {
    "Open sidebar" : "Buka jendela samping",
    "Delete" : "Hapus"
},
"nplurals=1; plural=0;");
