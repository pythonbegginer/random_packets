OC.L10N.register(
    "notifications",
    {
    "in {path}" : "{path} တွင်"
},
"nplurals=1; plural=0;");
