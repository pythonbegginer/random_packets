OC.L10N.register(
    "notifications",
    {
    "in {path}" : "dalam {haluan}"
},
"nplurals=1; plural=0;");
