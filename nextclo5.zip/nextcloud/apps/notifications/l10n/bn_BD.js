OC.L10N.register(
    "notifications",
    {
    "Notifications" : "বার্তাসমূহ",
    "seconds ago" : "সেকেন্ড পূর্বে"
},
"nplurals=2; plural=(n != 1);");
