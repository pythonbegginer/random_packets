OC.L10N.register(
    "notifications",
    {
    "Admin notifications" : "ადმინისტრაციული შეტყობინებები",
    "Notifications" : "შეტყობინებები",
    "No notifications" : "შეტყობინებები არაა",
    "Failed to dismiss all notifications" : "ყველა შეტყობინების გათავისუფლება ვერ მოხერხდა",
    "Failed to perform action" : "მოქმედების შესრულება ვერ მოხერხდა",
    "Dismiss" : "უარყოფა",
    "seconds ago" : "წამის წინ",
    "Failed to dismiss notification" : "შეტყობინების გათავისუფლება ვერ მოხერხდა",
    "in {path}" : "{path}-ში"
},
"nplurals=2; plural=(n!=1);");
