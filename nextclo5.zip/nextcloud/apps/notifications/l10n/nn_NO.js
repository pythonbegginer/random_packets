OC.L10N.register(
    "notifications",
    {
    "Notifications" : "Meldingar",
    "Dismiss" : "Forkast",
    "seconds ago" : "sekund sidan",
    "in {path}" : "i {spor}"
},
"nplurals=2; plural=(n != 1);");
