OC.L10N.register(
    "notifications",
    {
    "Notifications" : "ការ​ជូន​ដំណឹង",
    "seconds ago" : "វិនាទី​មុន"
},
"nplurals=1; plural=0;");
