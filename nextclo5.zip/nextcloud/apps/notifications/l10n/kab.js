OC.L10N.register(
    "notifications",
    {
    "in {path}" : "deg {ubrid}"
},
"nplurals=2; plural=(n != 1);");
