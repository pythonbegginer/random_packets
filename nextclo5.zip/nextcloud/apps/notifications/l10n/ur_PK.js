OC.L10N.register(
    "notifications",
    {
    "seconds ago" : "سیکنڈز پہلے"
},
"nplurals=2; plural=(n != 1);");
