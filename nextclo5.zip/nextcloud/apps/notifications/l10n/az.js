OC.L10N.register(
    "notifications",
    {
    "Notifications" : "Xəbərdarlıqlar",
    "seconds ago" : "saniyələr öncə"
},
"nplurals=2; plural=(n != 1);");
