OC.L10N.register(
    "notifications",
    {
    "seconds ago" : "செக்கன்களுக்கு முன்"
},
"nplurals=2; plural=(n != 1);");
