OC.L10N.register(
    "notifications",
    {
    "Notifications" : "Avisos",
    "No notifications" : "Nun hai avisos",
    "Failed to dismiss all notifications" : "Fall al escartar tolos avisos",
    "Dismiss" : "Escartar",
    "seconds ago" : "hai segundos",
    "Failed to dismiss notification" : "Fallu al escartar l'avisu",
    "in {path}" : "en {path}"
},
"nplurals=2; plural=(n != 1);");
