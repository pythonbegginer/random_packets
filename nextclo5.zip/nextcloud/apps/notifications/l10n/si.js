OC.L10N.register(
    "notifications",
    {
    "Notifications" : "දැනුම්දීම්",
    "seconds ago" : "තත්පර කිහිපයකට පෙර"
},
"nplurals=2; plural=(n != 1);");
