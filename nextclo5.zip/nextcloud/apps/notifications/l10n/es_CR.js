OC.L10N.register(
    "notifications",
    {
    "Admin notifications" : "Notificaciones adminsitrativas",
    "Notifications" : "Notificaciones",
    "No notifications" : "No hay notificaciones",
    "Failed to dismiss all notifications" : "Se presentó una falla al descartar todas las notificaciones",
    "Failed to perform action" : "Se presentó una falla al ejeuctar la acción",
    "Dismiss" : "Descartar",
    "seconds ago" : "hace segundos",
    "Failed to dismiss notification" : "Se presentó una falla al descartar la notificación",
    "in {path}" : "en {path}"
},
"nplurals=2; plural=(n != 1);");
