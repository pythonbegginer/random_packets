OC.L10N.register(
    "notifications",
    {
    "Admin notifications" : "Notificaciones del administrador",
    "Notifications" : "Notificaciones",
    "Dismiss all notifications" : "Descartar todos los permisos",
    "Requesting browser permissions to show notifications" : "Solicitando permisos del navegador para mostrar notificaciones",
    "No notifications" : "No hay notificaciones",
    "Dismiss" : "Descartar",
    "seconds ago" : "hace segundos",
    "in {path}" : "en {path}"
},
"nplurals=2; plural=(n != 1);");
