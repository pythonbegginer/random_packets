OC.L10N.register(
    "notifications",
    {
    "Admin notifications" : "Административни известия",
    "Notifications" : "Известия",
    "This app provides a backend and frontend for the notification API available in Nextcloud." : "Това приложение осигурява сървър и интерфейс за API известие, наличен в Nextcloud.",
    "This app provides a backend and frontend for the notification API available in Nextcloud.\n\t\tThe API is used by other apps to notify users in the web UI and sync clients about various things. Some examples are:\n\n📬 Federated file sharing: You received a new remote share\n\n📑 Comments: Another user mentioned you in a comment on a file\n\n🚢 Update notification: Available update for an app or nextcloud itself\n\n📣 Announcement center: An announcement was posted by an admin" : "Това приложение осигурява ссссървър и интерфейс за API уведомяване, наличен в Nextcloud.\n\t\tAPI се използва от други приложения, за да уведомява потребителите в уеб потребителския интерфейс и да синхронизира клиенти за различни неща. Ето няколко примера:\n\n📬 Федерирано споделяне на файлове: Получихте ново отдалечено споделяне\n\n📑 Коментари: Друг потребител ви спомена в коментар за файл\n\n🚢 Известие за актуализация: Налична актуализация за приложение или самият nextcloud\n\n📣  Център за съобщения: Съобщение е публикувано от администратор",
    "Dismiss all notifications" : "Откажи всички съобщения",
    "Requesting browser permissions to show notifications" : "Заявка за права на браузъра за показване на известия",
    "No notifications" : "Няма известия",
    "Failed to dismiss all notifications" : "Неуспешно отхвърляне на всичко известия",
    "Failed to perform action" : "Грешка при изпълнение на действие",
    "Dismiss" : "Отхвърляне",
    "seconds ago" : "преди секунди",
    "Failed to dismiss notification" : "Неуспешен опит за отхвърляне на известие",
    "in {path}" : "в {path}"
},
"nplurals=2; plural=(n != 1);");
