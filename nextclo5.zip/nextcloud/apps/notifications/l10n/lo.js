OC.L10N.register(
    "notifications",
    {
    "seconds ago" : "ວິນາທີຜ່ານມາ"
},
"nplurals=1; plural=0;");
