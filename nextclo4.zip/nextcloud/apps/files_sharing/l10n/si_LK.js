OC.L10N.register(
    "files_sharing",
    {
    "Cancel" : "එපා",
    "Sharing" : "හුවමාරු කිරීම",
    "A file or folder has been <strong>shared</strong>" : "ගොනුවක් හෝ ෆෝල්ඩරයක් <strong>හවුල්</strong> වී ඇත",
    "Password" : "මුර පදය",
    "Name" : "නම",
    "Download" : "බාන්න"
},
"nplurals=2; plural=(n != 1);");
