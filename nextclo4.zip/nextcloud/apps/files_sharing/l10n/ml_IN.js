OC.L10N.register(
    "files_sharing",
    {
    "A file or folder has been <strong>shared</strong>" : "ഒരു ഫയലോ അറയോ <strong>പങ്കിട്ടിരിക്കുന്നു</strong>",
    "You shared %1$s with %2$s" : "നിങ്ങൾ %1$s %2$sനു പങ്കുവെച്ചു",
    "You shared %1$s with group %2$s" : "നിങ്ങൾ %1$s %2$s കൂട്ടത്തിന് പങ്കുവെച്ചു",
    "You shared %1$s via link" : "താങ്കൾ %1$s ലിങ്കിലൂടെ പങ്കുവെച്ചിരിക്കുന്നു",
    "%2$s shared %1$s with you" : "%2$s %1$s നിങ്ങൾക്ക് പങ്കുവെച്ചു",
    "Shares" : "പങ്കിടലുകൾ"
},
"nplurals=2; plural=(n != 1);");
