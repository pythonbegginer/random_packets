OC.L10N.register(
    "files_sharing",
    {
    "Sharing" : "ການແບ່ງປັນ"
},
"nplurals=1; plural=0;");
