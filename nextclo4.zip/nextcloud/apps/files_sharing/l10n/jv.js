OC.L10N.register(
    "files_sharing",
    {
    "Download" : "Njipuk"
},
"nplurals=2; plural=(n != 1);");
