OC.L10N.register(
    "files_sharing",
    {
    "Cancel" : "﻿ರದ್ದು",
    "Sharing" : "﻿ಹಂಚಿಕೆ",
    "Password" : "ಗುಪ್ತ ಪದ",
    "Name" : "﻿ಹೆಸರು",
    "Download" : "ಪ್ರತಿಯನ್ನು ಸ್ಥಳೀಯವಾಗಿ ಉಳಿಸಿಕೊಳ್ಳಿ"
},
"nplurals=1; plural=0;");
