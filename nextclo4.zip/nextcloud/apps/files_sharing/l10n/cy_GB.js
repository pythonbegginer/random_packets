OC.L10N.register(
    "files_sharing",
    {
    "Cancel" : "Diddymu",
    "Shared by" : "Rhannwyd gan",
    "Password" : "Cyfrinair",
    "Name" : "Enw",
    "Download" : "Llwytho i lawr"
},
"nplurals=4; plural=(n==1) ? 0 : (n==2) ? 1 : (n != 8 && n != 11) ? 2 : 3;");
