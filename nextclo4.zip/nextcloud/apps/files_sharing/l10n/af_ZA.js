OC.L10N.register(
    "files_sharing",
    {
    "Cancel" : "Kanseleer",
    "Password" : "Wagwoord"
},
"nplurals=2; plural=(n != 1);");
