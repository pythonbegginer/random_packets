OC.L10N.register(
    "files_sharing",
    {
    "A file or folder has been <strong>shared</strong>" : "ஒரு கோப்புறை அல்லது ஆவணம் <strong> பகிர்வு செய்யப்பட்டுள்ளது.</strong>",
    "You shared %1$s with %2$s" : "நீங்கள் %1$s 'ஐ %2$s உடன் பகிர்ந்துள்ளிர்கள். ",
    "You shared %1$s with group %2$s" : "நீங்கள் %1$s 'ஐ %2$s குழுவுடன்  உடன் பகிர்ந்துள்ளிர்கள்.",
    "You shared %1$s via link" : "நீங்கள் %1$s 'ஐ இணைப்பு மூலம் பகிர்ந்துள்ளிர்கள்.",
    "%2$s shared %1$s with you" : "%2$s %1$s 'ஐ உங்களுடன் பகிர்ந்துள்ளார்.",
    "Shares" : "பகிர்வுகள் "
},
"nplurals=2; plural=(n != 1);");
