OC.L10N.register(
    "files_sharing",
    {
    "Cancel" : "বাতিল করা",
    "A file or folder has been <strong>shared</strong>" : "ফাইল অথবা ফোল্ডার <strong>শেয়ার করা হয়েছে</strong>",
    "You shared %1$s with %2$s" : "আপনি %1$s শেয়ার করছেন %2$s এর সাথে",
    "You shared %1$s with group %2$s" : "আপনি %1$s কে %2$s গ্রুপের সাথে শেয়ার করেছেন",
    "You shared %1$s via link" : "আপনি লিঙ্ক দ্বারা %1$s শেয়ার করুন ",
    "%2$s shared %1$s with you" : "%2$s শেয়ার করেছে %1$s কে আপনার সাথে ",
    "Shares" : "শেয়ারস",
    "Name" : "নাম",
    "Download" : "ডাউনলোড করুন"
},
"nplurals=2; plural=(n != 1);");
