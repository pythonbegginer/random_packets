OC.L10N.register(
    "files_sharing",
    {
    "Cancel" : "I-cancel",
    "Password" : "Password",
    "Download" : "I-download"
},
"nplurals=2; plural=(n > 1);");
