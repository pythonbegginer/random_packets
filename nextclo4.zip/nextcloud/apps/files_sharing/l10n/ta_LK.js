OC.L10N.register(
    "files_sharing",
    {
    "Cancel" : "இரத்து செய்க",
    "Password" : "கடவுச்சொல்",
    "Name" : "பெயர்",
    "Download" : "பதிவிறக்குக"
},
"nplurals=2; plural=(n != 1);");
