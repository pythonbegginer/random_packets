OC.L10N.register(
    "comments",
    {
    "Type in a new comment..." : "Escriure un comentari novèl...",
    "Delete comment" : "Suprimir lo comentari",
    "Post" : "Mandar",
    "Cancel" : "Anullar",
    "Edit comment" : "Modificar lo comentari",
    "[Deleted user]" : "[Utilizaire suprimit]",
    "Comments" : "Comentaris",
    "No other comments available" : "Pas cap d'autre comentari",
    "More comments..." : "Mai de comentaris...",
    "Save" : "Enregistrar",
    "Allowed characters {count} of {max}" : "{count} sus {max} caractèrs autorizats",
    "{count} unread comments" : "{count} comentaris pas legits",
    "Comment" : "Comentar",
    "<strong>Comments</strong> for files <em>(always listed in stream)</em>" : "<strong>Comentaris</strong> pels fichièrs <em>(totjorn listats dins lo flux)</em>",
    "You commented" : "Avètz comentat",
    "%1$s commented" : "%1$s a comentat",
    "You commented on %2$s" : "Avètz comentat %2$s",
    "%1$s commented on %2$s" : "%1$s a comentat %2$s"
},
"nplurals=2; plural=(n > 1);");
