OC.L10N.register(
    "comments",
    {
    "Cancel" : "ပယ်ဖျက်မည်"
},
"nplurals=1; plural=0;");
