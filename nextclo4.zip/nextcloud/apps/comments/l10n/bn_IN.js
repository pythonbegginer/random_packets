OC.L10N.register(
    "comments",
    {
    "Cancel" : "বাতিল করা",
    "Save" : "সেভ"
},
"nplurals=2; plural=(n != 1);");
