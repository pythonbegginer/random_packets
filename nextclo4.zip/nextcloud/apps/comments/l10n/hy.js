OC.L10N.register(
    "comments",
    {
    "Cancel" : "Չեղարկել",
    "Save" : "Պահպանել"
},
"nplurals=2; plural=(n != 1);");
