<?php 
$OC_Version = array(22,1,0,1);
$OC_VersionString = '22.1.0';
$OC_Edition = '';
$OC_Channel = 'stable';
$OC_VersionCanBeUpgradedFrom = array (
  'nextcloud' => 
  array (
    '21.0' => true,
    '22.0' => true,
    '22.1' => true,
  ),
  'owncloud' => 
  array (
    '10.5' => true,
  ),
);
$OC_Build = '2021-08-04T05:44:18+00:00 525ff78aab408b7205f50e67a8129bb504147e61';
$vendor = 'nextcloud';
