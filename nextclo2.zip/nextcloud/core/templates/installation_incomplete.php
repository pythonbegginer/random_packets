<div class="error">
	<h2><?php p($l->t('Error')) ?></h2>
	<p>
		<?php p($l->t('Could not remove CAN_INSTALL from the config folder. Please remove this file manually.')) ?>
	</p>
</div>
