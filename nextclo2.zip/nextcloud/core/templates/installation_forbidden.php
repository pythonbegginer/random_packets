<div class="error">
	<h2><?php p($l->t('Error')) ?></h2>
	<p>
		<?php p($l->t('It looks like you are trying to reinstall your Nextcloud. However the file CAN_INSTALL is missing from your config directory. Please create the file CAN_INSTALL in your config folder to continue.')) ?>
	</p>
</div>
